![POLITICO](https://rawgithub.com/The-Politico/src/master/images/logo/badge.png)

![](dist/images/share.jpg)

# interactive_judging

| Title | judging |
|-|-|
| Developer    | []() |
| Link | [https://www.politico.com/interactives/2019/judging/](https://www.politico.com/interactives/2019/judging/) |


©2019 POLITICO
